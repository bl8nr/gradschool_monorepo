## CSCI E-118: Homework 1 
### Brett Bloethner

#### Problem 1
The solution to problem 1 is in the file problem1.py and includes a few tests to confirm the solutions accuracy. To run these tests, while in this directory use the following command...

    python3 problem1.py

Please note that to run these .py files locally, you must have the python 3 command line runtime installed and problem4.py has a dependency of the 'time' library and imports 'time'

#### Problem 4
The solution to problem 4 is in the file problem4.py and also includes a few test to confirm the solutions accuracy. The run these tests, while in this directory use the following command...

    python3 problem4.py

For problem 4 string palindromes are tested as well as 2d palindromes. For this problem I calculated a 2d palindrome in the sense that column0 == column4 and row0 == row4.