package com.cscie97.smartcity.controller;

public enum EmergencyOneTypeEnum {
    FIRE,
    FLOOD,
    EARTHQUAKE,
    SEVERE_WEATHER
}
