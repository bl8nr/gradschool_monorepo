package com.cscie97.smartcity.controller;

public enum EmergencyTwoTypeEnum {
    TRAFFIC_ACCIDENT
}
