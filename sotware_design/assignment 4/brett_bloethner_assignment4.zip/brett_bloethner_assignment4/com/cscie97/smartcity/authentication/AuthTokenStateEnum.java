package com.cscie97.smartcity.authentication;

public enum AuthTokenStateEnum {
    ACTIVE,
    INACTIVE
}
