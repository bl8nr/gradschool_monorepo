package com.cscie97.smartcity.model;

public enum SensorOutputTypeEnum {
    SPEAKER
}
