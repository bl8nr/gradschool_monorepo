package com.cscie97.smartcity.model;

public enum CurrentStatusEnum {
    READY,
    OFFLINE
}
