package com.cscie97.smartcity.model;

public enum VehicleTypeEnum {
    CAR,
    BUS
}
