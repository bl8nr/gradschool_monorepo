package com.cscie97.smartcity.model;

public class Main {
    public static void main(String[] args) {

    }
}
