package com.cscie97.smartcity.ledger;

public class Main {

    public static void main(String[] args) {

    }
}
