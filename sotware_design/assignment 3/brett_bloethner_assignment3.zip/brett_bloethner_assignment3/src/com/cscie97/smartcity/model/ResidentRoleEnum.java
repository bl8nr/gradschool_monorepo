package com.cscie97.smartcity.model;

public enum ResidentRoleEnum {
    ADULT,
    CHILD,
    PUBLIC_ADMINISTRATOR
}
