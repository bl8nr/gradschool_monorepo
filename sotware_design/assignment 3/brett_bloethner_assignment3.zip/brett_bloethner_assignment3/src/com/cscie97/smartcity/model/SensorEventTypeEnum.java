package com.cscie97.smartcity.model;

public enum SensorEventTypeEnum {
    MICROPHONE,
    CAMERA,
    THERMOMETER,
    CO2METER
}
